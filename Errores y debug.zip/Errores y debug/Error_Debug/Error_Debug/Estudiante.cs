﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Error_Debug
{
    public class Estudiante
    {//encapsulacion de los datos
        public string Nombre { get; set; }
        public string Carrera { get; set; }
        public int Semestre { get; set; }
        public int Matricula { get; set; }
        
    }
}
